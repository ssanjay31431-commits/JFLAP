# Design, Minimization and Parsing of Formal Languages using JFLAP

**Course:** 21CSC301T – Formal Language and Automata (2026-2027)
**Student:** SANJAY SUNDAR – RA2411008050039
**Department of Information Technology, SRM IST Tiruchirappalli**

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/ssanjay31431-commits/JFLAP/blob/main/FLA_JFLAP_Project.ipynb)

This project designs 10 automata and grammars in **JFLAP**. It then re-implements them in Python and checks them against a labelled dataset of **2,413 test strings**. All 2,413 strings match (100%).

## Project links

| Item | Link |
|---|---|
| Data set name | FLA Automata Test Strings Dataset |
| Data set link | https://github.com/ssanjay31431-commits/JFLAP/blob/main/dataset/fla_automata_test_strings.csv |
| GitHub code | https://github.com/ssanjay31431-commits/JFLAP |
| Colab notebook | https://colab.research.google.com/github/ssanjay31431-commits/JFLAP/blob/main/FLA_JFLAP_Project.ipynb |
| Report (PDF) | [report/REPORT_FLA_RA39.pdf](report/REPORT_FLA_RA39.pdf) |

## Topics

| # | Topic | JFLAP file | Screenshot |
|---|---|---|---|
| 1 | DFA – binary numbers divisible by 3 | `jflap/dfa3.jff` | `screenshots/01_run.png` |
| 2 | NFA – strings containing 101, NFA → DFA | `jflap/nfa101.jff` | `screenshots/02_run.png`, `02_conv.png` |
| 3 | DFA minimization (ends with abb) | `jflap/mindfa.jff` | `screenshots/03_tree.png`, `03_min.png` |
| 4 | Moore machine – remainder mod 3 | `jflap/moore.jff` | `screenshots/04_run.png` |
| 5 | Mealy machine – detect 01 | `jflap/mealy.jff` | `screenshots/05_run.png` |
| 6 | Right-linear grammar → FA | `jflap/rlg.jff` | `screenshots/06_conv.png` |
| 7 | Brute force parse – expression grammar | `jflap/expr.jff` | `screenshots/07_tree.png` |
| 8 | CYK parsing – CNF grammar | `jflap/cyk.jff` | `screenshots/08_tree.png` |
| 9 | PDA – balanced parentheses | `jflap/pda.jff` | `screenshots/09_run.png` |
| 10 | Turing machine – binary increment | `jflap/tm.jff` | `screenshots/10_run.png` |

## Dataset

`dataset/fla_automata_test_strings.csv` has 2,413 rows with these columns:

| Column | Meaning |
|---|---|
| `machine_id` | M01 – M10 (topic number) |
| `machine_type`, `language`, `jflap_file` | Which machine is tested |
| `input` | Test string (`λ` = empty string) |
| `length` | Length of the input |
| `expected_result` | Accept / Reject |
| `expected_output` | Output for Moore, Mealy and Turing machine (transducers) |
| `shown_in_report` | True if the string appears in the JFLAP screenshots |

The expected answers come from the **definition of each language** (for example, `int(w, 2) % 3 == 0` or "contains 101"), not from the automata. This means the dataset tests the machines independently. To rebuild it, run `python src/make_dataset.py`.

## Repository structure

```
FLA_JFLAP_Project.ipynb   Colab notebook (simulators + verification + diagrams)
dataset/                  Test string dataset (CSV)
jflap/                    JFLAP .jff files – open with JFLAP 7.1
report/                   Project report (PDF and Word)
screenshots/              JFLAP screenshots used in the report
src/automata.py           Python simulators for all 10 machines
src/make_dataset.py       Builds the dataset
src/make_notebook.py      Builds the notebook
```

## How to run

**JFLAP:** download JFLAP 7.1 from jflap.org. Open any file in `jflap/` and use *Input → Multiple Run*.

**Colab:** click the badge above, then *Runtime → Run all*.

**Local:**
```bash
pip install -r requirements.txt
jupyter notebook FLA_JFLAP_Project.ipynb
```
