"""Python simulators for the 10 machines/grammars in the FLA JFLAP report.

Each machine mirrors the JFLAP .jff file of the same name in the jflap/ folder.
"""
from itertools import product

# ---------------- 1. DFA: binary numbers divisible by 3 ----------------
DFA3 = {
    "start": "q0", "finals": {"q0"},
    "delta": {("q0", "0"): "q0", ("q0", "1"): "q1",
              ("q1", "0"): "q2", ("q1", "1"): "q0",
              ("q2", "0"): "q1", ("q2", "1"): "q2"},
}


def run_dfa(dfa, w):
    s = dfa["start"]
    for c in w:
        s = dfa["delta"].get((s, c))
        if s is None:
            return False
    return s in dfa["finals"]


# ---------------- 2. NFA: strings containing 101 ----------------
NFA101 = {
    "start": "q0", "finals": {"q3"}, "alphabet": "01",
    "delta": {("q0", "0"): {"q0"}, ("q0", "1"): {"q0", "q1"},
              ("q1", "0"): {"q2"}, ("q2", "1"): {"q3"},
              ("q3", "0"): {"q3"}, ("q3", "1"): {"q3"}},
}


def run_nfa(nfa, w):
    cur = {nfa["start"]}
    for c in w:
        cur = set().union(*[nfa["delta"].get((s, c), set()) for s in cur]) if cur else set()
    return bool(cur & nfa["finals"])


def nfa_to_dfa(nfa):
    """Subset construction. Returns (dfa, list_of_subsets)."""
    start = frozenset({nfa["start"]})
    order, todo, delta = [start], [start], {}
    while todo:
        S = todo.pop(0)
        for c in nfa["alphabet"]:
            T = frozenset(set().union(*[nfa["delta"].get((s, c), set()) for s in S]))
            delta[(S, c)] = T
            if T not in order:
                order.append(T)
                todo.append(T)
    name = {S: f"D{i}" for i, S in enumerate(order)}
    dfa = {"start": name[start],
           "finals": {name[S] for S in order if S & nfa["finals"]},
           "delta": {(name[S], c): name[T] for (S, c), T in delta.items()}}
    return dfa, [(name[S], sorted(S)) for S in order]


# ---------------- 3. DFA minimization (ends with abb) ----------------
MINDFA = {
    "start": "A", "finals": {"E"}, "alphabet": "ab",
    "delta": {("A", "a"): "B", ("A", "b"): "C", ("B", "a"): "B", ("B", "b"): "D",
              ("C", "a"): "B", ("C", "b"): "C", ("D", "a"): "B", ("D", "b"): "E",
              ("E", "a"): "B", ("E", "b"): "C"},
}


def minimize(dfa):
    """Partition refinement. Returns list of groups (sets of equivalent states)."""
    states = sorted({s for s, _ in dfa["delta"]})
    parts = [set(dfa["finals"]), set(states) - set(dfa["finals"])]
    parts = [p for p in parts if p]
    changed = True
    while changed:
        changed = False
        new = []
        for P in parts:
            groups = {}
            for s in P:
                key = tuple(next(i for i, Q in enumerate(parts) if dfa["delta"][(s, c)] in Q)
                            for c in dfa["alphabet"])
                groups.setdefault(key, set()).add(s)
            new.extend(groups.values())
            changed |= len(groups) > 1
        parts = new
    return sorted(parts, key=lambda g: sorted(g))


# ---------------- 4. Moore machine: remainder mod 3 ----------------
MOORE_OUT = {"q0": "0", "q1": "1", "q2": "2"}


def run_moore(w):
    s, out = "q0", MOORE_OUT["q0"]
    for c in w:
        s = DFA3["delta"][(s, c)]
        out += MOORE_OUT[s]
    return out


# ---------------- 5. Mealy machine: detect 01 ----------------
MEALY = {("q0", "0"): ("q1", "0"), ("q0", "1"): ("q0", "0"),
         ("q1", "0"): ("q1", "0"), ("q1", "1"): ("q0", "1")}


def run_mealy(w):
    s, out = "q0", ""
    for c in w:
        s, o = MEALY[(s, c)]
        out += o
    return out


# ---------------- 6. Right-linear grammar -> FA ----------------
RLG = {"S": ["aS", "bA"], "A": ["bA", "a"]}


def rlg_to_fa(g, start="S"):
    delta, final = {}, "F"
    for A, rhss in g.items():
        for r in rhss:
            if len(r) == 2:
                delta.setdefault((A, r[0]), set()).add(r[1])
            else:
                delta.setdefault((A, r[0]), set()).add(final)
    return {"start": start, "finals": {final}, "delta": delta, "alphabet": "ab"}


# ---------------- 7 & 8. CFG parsing ----------------
EXPR = {"E": ["E+T", "T"], "T": ["T*F", "F"], "F": ["(E)", "a"]}


def parse_expr(w):
    """Recognizer for E -> E+T | T, T -> T*F | F, F -> (E) | a
    (recursive descent on the equivalent non-left-recursive grammar)."""
    pos = 0

    def peek():
        return w[pos] if pos < len(w) else None

    def E():
        nonlocal pos
        if not T():
            return False
        while peek() == "+":
            pos += 1
            if not T():
                return False
        return True

    def T():
        nonlocal pos
        if not F():
            return False
        while peek() == "*":
            pos += 1
            if not F():
                return False
        return True

    def F():
        nonlocal pos
        if peek() == "a":
            pos += 1
            return True
        if peek() == "(":
            pos += 1
            if not E() or peek() != ")":
                return False
            pos += 1
            return True
        return False

    return E() and pos == len(w)


CNF = {"S": ["AB", "BC"], "A": ["BA", "a"], "B": ["CC", "b"], "C": ["AB", "a"]}


def cyk(g, w, start="S"):
    n = len(w)
    if n == 0:
        return False, []
    T = [[set() for _ in range(n)] for _ in range(n)]
    for i, c in enumerate(w):
        T[0][i] = {X for X, rs in g.items() if c in rs}
    for l in range(2, n + 1):
        for i in range(n - l + 1):
            for k in range(1, l):
                for X, rs in g.items():
                    for r in rs:
                        if len(r) == 2 and r[0] in T[k - 1][i] and r[1] in T[l - k - 1][i + k]:
                            T[l - 1][i].add(X)
    return start in T[n - 1][0], T


# ---------------- 9. PDA: balanced parentheses ----------------
def run_pda(w):
    stack = ["Z"]
    for c in w:
        if c == "(":
            stack.append("(")
        elif c == ")" and stack[-1] == "(":
            stack.pop()
        else:
            return False
    return stack == ["Z"]  # lambda,Z;Z -> final q1


# ---------------- 10. TM: binary increment ----------------
TM = {("q0", "0"): ("q0", "0", 1), ("q0", "1"): ("q0", "1", 1), ("q0", "_"): ("q1", "_", -1),
      ("q1", "1"): ("q1", "0", -1), ("q1", "0"): ("q2", "1", -1), ("q1", "_"): ("q2", "1", -1),
      ("q2", "0"): ("q2", "0", -1), ("q2", "1"): ("q2", "1", -1), ("q2", "_"): ("q3", "_", 1)}


def run_tm(w, max_steps=10_000):
    tape = dict(enumerate(w))
    s, h = "q0", 0
    for _ in range(max_steps):
        if s == "q3":
            out = "".join(tape.get(i, "_") for i in range(h, max(tape) + 1)).strip("_")
            return True, out
        key = (s, tape.get(h, "_"))
        if key not in TM:
            return False, None
        s, sym, mv = TM[key]
        tape[h] = sym
        h += mv
    return False, None


def strings(alphabet, max_len, min_len=0):
    for n in range(min_len, max_len + 1):
        for t in product(alphabet, repeat=n):
            yield "".join(t)
