"""Builds FLA_JFLAP_Project.ipynb (Google Colab notebook)."""
import os
import nbformat as nbf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO = "ssanjay31431-commits/JFLAP"
code_automata = open(os.path.join(ROOT, "src", "automata.py"), encoding="utf-8").read()

nb = nbf.v4.new_notebook()
C = []
md = lambda s: C.append(nbf.v4.new_markdown_cell(s))
code = lambda s: C.append(nbf.v4.new_code_cell(s))

md(f"""# Design, Minimization and Parsing of Formal Languages using JFLAP
**Course:** 21CSC301T – Formal Language and Automata
**Name:** SANJAY SUNDAR  **Register No.:** RA2411008050039
**Department of Information Technology, SRM IST Tiruchirappalli**

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/{REPO}/blob/main/FLA_JFLAP_Project.ipynb)

This notebook re-implements the 10 machines from the JFLAP report in Python and checks them
against the **FLA Automata Test Strings dataset** (2,413 labelled strings).
The expected answer in the dataset comes from the mathematical definition of each language,
so the dataset checks the machines independently.

| # | Topic | JFLAP file |
|---|---|---|
| 1 | DFA – binary numbers divisible by 3 | `dfa3.jff` |
| 2 | NFA – strings containing 101 + NFA→DFA | `nfa101.jff` |
| 3 | DFA minimization (ends with abb) | `mindfa.jff` |
| 4 | Moore machine – remainder mod 3 | `moore.jff` |
| 5 | Mealy machine – detect 01 | `mealy.jff` |
| 6 | Right-linear grammar → FA | `rlg.jff` |
| 7 | Brute force parsing – expression grammar | `expr.jff` |
| 8 | CYK parsing – CNF grammar | `cyk.jff` |
| 9 | PDA – balanced parentheses | `pda.jff` |
| 10 | Turing machine – binary increment | `tm.jff` |
""")

md("## 1. Setup")
code("""!pip -q install graphviz
import os, pandas as pd, matplotlib.pyplot as plt, graphviz
from IPython.display import display""")

md("## 2. Automata simulators\nThe same code as `src/automata.py` in the GitHub repository.")
code(code_automata)

md("## 3. Load the dataset")
code(f"""URL = "https://raw.githubusercontent.com/{REPO}/main/dataset/fla_automata_test_strings.csv"
LOCAL = "dataset/fla_automata_test_strings.csv"
src = LOCAL if os.path.exists(LOCAL) else URL
df = pd.read_csv(src, keep_default_na=False, dtype={{"input": str, "expected_output": str}})
df["w"] = df["input"].replace("λ", "")
print("Loaded", len(df), "rows")
df.head(10)""")
code("""summary = df.pivot_table(index=["machine_id", "machine_type"], columns="expected_result",
                         values="input", aggfunc="count", fill_value=0)
display(summary)
summary.plot(kind="barh", stacked=True, figsize=(9, 5), color=["#4C9F70", "#D9534F"])
plt.title("Dataset: strings per machine"); plt.xlabel("Number of strings"); plt.tight_layout(); plt.show()""")

md("## 4. Helper: draw an automaton")
code("""def draw(delta, start, finals, label_fn=lambda k, v: k[1], name=""):
    g = graphviz.Digraph(name, graph_attr={"rankdir": "LR"})
    g.attr("node", shape="circle", style="filled", fillcolor="#FFFF99")
    g.node("", shape="none", width="0")
    states = {k[0] for k in delta} | {t for v in delta.values() for t in (v if isinstance(v, (set, frozenset)) else [v if isinstance(v, str) else v[0]])}
    for s in sorted(states):
        g.node(s, shape="doublecircle" if s in finals else "circle")
    g.edge("", start)
    edges = {}
    for k, v in delta.items():
        targets = v if isinstance(v, (set, frozenset)) else [v if isinstance(v, str) else v[0]]
        for t in targets:
            edges.setdefault((k[0], t), []).append(label_fn(k, v))
    for (a, b), labs in edges.items():
        g.edge(a, b, label=", ".join(labs))
    return g

def check(mid, fn):
    d = df[df.machine_id == mid].copy()
    d["got"] = d["w"].map(fn)
    ok = (d["got"] == d["expected"]).mean() * 100
    print(f"{mid}: {len(d)} strings, {ok:.1f}% match")
    return d""")

md("## 5. Topic 1 – DFA for binary numbers divisible by 3")
code("""display(draw(DFA3["delta"], "q0", DFA3["finals"]))
df["expected"] = df["expected_result"]
r1 = check("M01", lambda w: "Accept" if run_dfa(DFA3, w) else "Reject")
r1[r1.shown_in_report][["input", "expected_result", "got"]]""")

md("## 6. Topic 2 – NFA for strings containing 101 and subset construction")
code("""display(draw(NFA101["delta"], "q0", NFA101["finals"]))
r2 = check("M02", lambda w: "Accept" if run_nfa(NFA101, w) else "Reject")
dfa, subsets = nfa_to_dfa(NFA101)
print("Subset construction:")
display(pd.DataFrame([(n, "{" + ",".join(s) + "}", dfa["delta"][(n, "0")], dfa["delta"][(n, "1")], n in dfa["finals"])
                      for n, s in subsets], columns=["DFA state", "NFA set", "on 0", "on 1", "final"]))
display(draw(dfa["delta"], dfa["start"], dfa["finals"]))
r2b = check("M02", lambda w: "Accept" if run_dfa(dfa, w) else "Reject")""")

md("## 7. Topic 3 – DFA minimization")
code("""display(draw(MINDFA["delta"], "A", MINDFA["finals"]))
groups = minimize(MINDFA)
print("Equivalence classes:", groups)
rep = {s: "".join(sorted(g)) for g in groups for s in g}
mdfa = {"start": rep["A"], "finals": {rep[s] for s in MINDFA["finals"]},
        "delta": {(rep[s], c): rep[t] for (s, c), t in MINDFA["delta"].items()}}
display(draw(mdfa["delta"], mdfa["start"], mdfa["finals"]))
print("States before:", 5, " after:", len(groups))
r3 = check("M03", lambda w: "Accept" if run_dfa(mdfa, w) else "Reject")""")

md("## 8. Topic 4 – Moore machine (remainder mod 3)")
code("""df.loc[df.machine_id.isin(["M04", "M05", "M10"]), "expected"] = df["expected_output"]
r4 = check("M04", run_moore)
r4[r4.shown_in_report][["input", "expected_output", "got"]]""")

md("## 9. Topic 5 – Mealy machine (detect 01)")
code("""display(draw(MEALY, "q0", set(), label_fn=lambda k, v: f"{k[1]};{v[1]}"))
r5 = check("M05", run_mealy)
r5[r5.shown_in_report][["input", "expected_output", "got"]]""")

md("## 10. Topic 6 – Right-linear grammar to FA")
code("""fa = rlg_to_fa(RLG)
display(draw(fa["delta"], "S", fa["finals"]))
r6 = check("M06", lambda w: "Accept" if run_nfa(fa, w) else "Reject")""")

md("## 11. Topic 7 – Expression grammar parsing")
code("""r7 = check("M07", lambda w: "Accept" if parse_expr(w) else "Reject")
r7.sample(10, random_state=1)[["input", "expected_result", "got"]]""")

md("## 12. Topic 8 – CYK parsing")
code("""ok, T = cyk(CNF, "baaba")
print("baaba accepted:", ok)
display(pd.DataFrame([[ "{" + ",".join(sorted(T[l][i])) + "}" for i in range(5 - l)] + [""] * l for l in range(5)],
                     index=[f"len {l+1}" for l in range(5)], columns=list("baaba")))
r8 = check("M08", lambda w: "Accept" if cyk(CNF, w)[0] else "Reject")""")

md("## 13. Topic 9 – PDA for balanced parentheses")
code("""r9 = check("M09", lambda w: "Accept" if run_pda(w) else "Reject")
r9[r9.shown_in_report][["input", "expected_result", "got"]]""")

md("## 14. Topic 10 – Turing machine binary increment")
code("""r10 = check("M10", lambda w: run_tm(w)[1])
r10[r10.shown_in_report][["input", "expected_output", "got"]]""")

md("## 15. Overall results")
code("""res = pd.concat([r1, r2, r3, r4, r5, r6, r7, r8, r9, r10])
acc = res.assign(match=res.got == res.expected).groupby(["machine_id", "machine_type"])["match"].agg(["count", "mean"])
acc["accuracy %"] = (acc.pop("mean") * 100).round(2)
display(acc)
ax = acc["accuracy %"].plot(kind="bar", figsize=(9, 4), color="#2E74B5", ylim=(0, 105))
ax.set_ylabel("Accuracy %"); ax.set_title("Simulator vs dataset (expected from language definition)")
ax.set_xticklabels([i[0] for i in acc.index], rotation=0); plt.tight_layout(); plt.show()
print(f"Overall: {(res.got == res.expected).sum()} / {len(res)} strings matched")""")

md("""## 16. Conclusion
All 10 machines designed in JFLAP were re-implemented in Python and tested on 2,413 labelled strings.
Every simulator agrees with the expected answers taken from the definition of each language,
and the outputs match the JFLAP screenshots in the report (Multiple Run, NFA→DFA, minimization,
brute force parser, CYK, PDA and Turing machine).""")

nb["cells"] = C
nb["metadata"] = {"colab": {"provenance": []}, "kernelspec": {"name": "python3", "display_name": "Python 3"},
                  "language_info": {"name": "python"}}
nbf.write(nb, os.path.join(ROOT, "FLA_JFLAP_Project.ipynb"))
print("notebook written")
