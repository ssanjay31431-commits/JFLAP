"""Builds dataset/fla_automata_test_strings.csv.

The expected answer for every row is computed from the mathematical definition
of the language (NOT from the automaton), so the dataset can be used to check
both the JFLAP machines and the Python simulators.
"""
import ast
import csv
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
from automata import CNF, strings  # noqa: E402

random.seed(39)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "dataset", "fla_automata_test_strings.csv")

# strings that appear in the JFLAP screenshots of the report
JFLAP = {
    "M01": ["0", "11", "110", "1001", "1100", "10", "101", "111"],
    "M02": ["101", "0101", "11011", "10101", "1001", "111", "0100", "110"],
    "M04": ["101", "110", "1001", "111", "10"],
    "M05": ["0101", "1001", "0011", "0110", "0001"],
    "M07": ["a+a*a"],
    "M08": ["baaba"],
    "M09": ["(())", "()()", "(()())", "((()))", "(()", "())", ")("],
    "M10": ["1011", "111", "100", "0", "1001"],
}

MACHINES = {
    "M01": ("DFA", "Binary numbers divisible by 3", "dfa3.jff"),
    "M02": ("NFA", "Binary strings containing substring 101", "nfa101.jff"),
    "M03": ("DFA (minimized)", "Strings over {a,b} ending with abb", "mindfa.jff"),
    "M04": ("Moore machine", "Remainder mod 3 of binary prefix", "moore.jff"),
    "M05": ("Mealy machine", "Output 1 when input so far ends with 01", "mealy.jff"),
    "M06": ("Right-linear grammar -> FA", "a* b+ a  (S->aS|bA, A->bA|a)", "rlg.jff"),
    "M07": ("CFG (brute force parse)", "Arithmetic expressions E->E+T|T, T->T*F|F, F->(E)|a", "expr.jff"),
    "M08": ("CFG in CNF (CYK)", "S->AB|BC, A->BA|a, B->CC|b, C->AB|a", "cyk.jff"),
    "M09": ("PDA", "Balanced parentheses", "pda.jff"),
    "M10": ("Turing machine", "Binary increment (adds 1)", "tm.jff"),
}


def valid_expr(w):
    if not w or re.search(r"[^a+*()]", w):
        return False
    try:
        tree = ast.parse(w.replace("a", "(1)"), mode="eval").body
    except SyntaxError:
        return False
    return all(isinstance(n, (ast.BinOp, ast.Constant, ast.Add, ast.Mult)) for n in ast.walk(tree))


def cnf_language(g, max_len, start="S"):
    """All terminal strings derivable from the CNF grammar, up to max_len (leftmost BFS)."""
    seen, out, todo = {start}, set(), [start]
    while todo:
        f = todo.pop()
        i = next((k for k, ch in enumerate(f) if ch.isupper()), None)
        if i is None:
            out.add(f)
            continue
        for r in g[f[i]]:
            nf = f[:i] + r + f[i + 1:]
            if len(nf) <= max_len and nf not in seen:
                seen.add(nf)
                todo.append(nf)
    return out


def rows():
    def row(mid, w, accept, output=""):
        kind, lang, jff = MACHINES[mid]
        return {"machine_id": mid, "machine_type": kind, "language": lang, "jflap_file": jff,
                "input": w if w else "λ", "length": len(w),
                "expected_result": "Accept" if accept else "Reject",
                "expected_output": output, "shown_in_report": w in JFLAP.get(mid, [])}

    for w in strings("01", 7):
        yield row("M01", w, int(w or "0", 2) % 3 == 0)
    for w in strings("01", 7):
        yield row("M02", w, "101" in w)
    for w in strings("ab", 7):
        yield row("M03", w, w.endswith("abb"))
    for w in strings("01", 6):
        out = "0" + "".join(str(int(w[:i + 1], 2) % 3) for i in range(len(w)))
        yield row("M04", w, True, out)
    for w in strings("01", 6):
        out = "".join("1" if w[:i + 1].endswith("01") else "0" for i in range(len(w)))
        yield row("M05", w, True, out)
    for w in strings("ab", 7):
        yield row("M06", w, re.fullmatch(r"a*b+a", w) is not None)
    exprs = list(strings("a+*()", 7, 1))
    good = [w for w in exprs if valid_expr(w)]
    bad = random.sample([w for w in exprs if not valid_expr(w)], len(good))
    for w in sorted(set(good) | set(bad), key=lambda s: (len(s), s)):
        yield row("M07", w, w in good)
    lang = cnf_language(CNF, 7)
    for w in strings("ab", 7, 1):
        yield row("M08", w, w in lang)
    for w in strings("()", 8):
        bal, d = True, 0
        for c in w:
            d += 1 if c == "(" else -1
            bal &= d >= 0
        yield row("M09", w, bal and d == 0)
    for w in strings("01", 7, 1):
        yield row("M10", w, True, format(int(w, 2) + 1, "0%db" % len(w)))


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    data = list(rows())
    with open(OUT, "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(data[0]))
        wr.writeheader()
        wr.writerows(data)
    print(f"wrote {len(data)} rows -> {OUT}")
